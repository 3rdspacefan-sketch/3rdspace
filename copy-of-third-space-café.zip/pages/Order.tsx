import React from 'react';
import { Button } from '../components/Button';
import { ShoppingBag, Coffee, ArrowRight } from 'lucide-react';

export const Order: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-brand-cream">
      {/* Hero */}
      <div className="bg-brand-green text-brand-cream py-16 px-6 text-center">
        <h1 className="font-serif text-5xl mb-4">Order Ahead</h1>
        <p className="text-lg opacity-80 max-w-2xl mx-auto">Skip the line, not the connection. Your drink will be ready at the bar.</p>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Card 1 */}
          <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square bg-brand-sand/30 rounded-sm mb-4 flex items-center justify-center text-brand-terra">
              <Coffee size={48} />
            </div>
            <h3 className="font-bold text-brand-green text-xl mb-2">Morning Brew</h3>
            <p className="text-sm text-brand-oak/70 mb-4">Fresh drip coffee, pour overs, and cold brew.</p>
            <div className="flex justify-between items-center">
               <span className="font-bold text-brand-oak">$3.50+</span>
               <button className="text-brand-terra font-bold text-sm uppercase flex items-center gap-1 hover:underline">Add <ArrowRight size={14}/></button>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square bg-brand-sand/30 rounded-sm mb-4 flex items-center justify-center text-brand-terra">
              <ShoppingBag size={48} />
            </div>
            <h3 className="font-bold text-brand-green text-xl mb-2">Pastries</h3>
            <p className="text-sm text-brand-oak/70 mb-4">Croissants, scones, and seasonal muffins.</p>
             <div className="flex justify-between items-center">
               <span className="font-bold text-brand-oak">$4.00+</span>
               <button className="text-brand-terra font-bold text-sm uppercase flex items-center gap-1 hover:underline">Add <ArrowRight size={14}/></button>
            </div>
          </div>

           {/* Card 3 */}
           <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-square bg-brand-sand/30 rounded-sm mb-4 flex items-center justify-center text-brand-terra">
              <Coffee size={48} />
            </div>
            <h3 className="font-bold text-brand-green text-xl mb-2">Espresso Bar</h3>
            <p className="text-sm text-brand-oak/70 mb-4">Lattes, cappuccinos, and cortados.</p>
             <div className="flex justify-between items-center">
               <span className="font-bold text-brand-oak">$4.50+</span>
               <button className="text-brand-terra font-bold text-sm uppercase flex items-center gap-1 hover:underline">Add <ArrowRight size={14}/></button>
            </div>
          </div>
        </div>
        
        <div className="bg-brand-sand/20 p-8 rounded-sm text-center">
           <p className="text-brand-oak/80 italic mb-4">Full online ordering menu coming soon.</p>
           <Button to="/coffee" variant="outline" className="rounded-full">View Seasonal Menu</Button>
        </div>
      </div>
    </div>
  );
};