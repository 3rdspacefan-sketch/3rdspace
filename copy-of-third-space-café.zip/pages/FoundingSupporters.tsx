
import React from 'react';
import { Button } from '../components/Button';
import { Heart, Sprout, Building2, ArrowRight } from 'lucide-react';
import { Translate } from '../components/Translate';

export const FoundingSupporters: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-brand-cream flex flex-col">
      
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 px-6 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?q=80&w=2049&auto=format&fit=crop" 
            alt="Warm light in a community space" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-brand-cream/80 via-brand-cream/90 to-brand-cream"></div>
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <span className="text-brand-terra font-bold tracking-widest uppercase text-sm mb-4 block">
            <Translate>A Vision for the City</Translate>
          </span>
          <h1 className="font-serif text-5xl md:text-7xl text-brand-green mb-8">
            <Translate>Founding Supporters</Translate>
          </h1>
          <div className="w-24 h-1 bg-brand-terra mx-auto rounded-full mb-8"></div>
          <p className="text-xl md:text-2xl text-brand-oak/80 italic font-serif max-w-2xl mx-auto">
            <Translate>"To plant a garden is to believe in tomorrow."</Translate>
          </p>
        </div>
      </section>

      {/* Section 1: The Circle */}
      <section className="max-w-7xl mx-auto px-6 py-12 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
             <div className="relative p-2 bg-white shadow-xl rotate-1 rounded-sm">
                <img 
                  src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?q=80&w=1932&auto=format&fit=crop" 
                  alt="Group of friends talking" 
                  className="w-full h-auto object-cover grayscale hover:grayscale-0 transition-all duration-700"
                />
                <div className="absolute -bottom-6 -right-6 bg-brand-terra text-white p-6 rounded-full shadow-lg hidden md:block">
                  <Heart size={32} />
                </div>
             </div>
          </div>
          
          <div className="order-1 md:order-2">
            <h2 className="font-serif text-4xl text-brand-green mb-6">
              <Translate>Laying the Foundation</Translate>
            </h2>
            <div className="prose prose-lg text-brand-oak/80 leading-relaxed">
              <p className="mb-6">
                <Translate>Third Space is registered as a non‑profit organization. We are forming a small circle of Founding Supporters who will help establish this vision from the beginning and shape a lasting place of blessing for our city.</Translate>
              </p>
              <p>
                <Translate>This is a unique opportunity to help build something that will serve the next generation. Rather than launching a public fundraising campaign, we are first inviting a trusted group to help lay the foundation for this vision.</Translate>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Visual Break: City Flourishing */}
      <section className="relative h-[500px] my-12 bg-fixed bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=2047&auto=format&fit=crop')" }}>
        <div className="absolute inset-0 bg-brand-green/40 mix-blend-multiply"></div>
        <div className="absolute inset-0 flex items-center justify-center text-center px-6">
           <div className="bg-brand-cream/95 p-10 md:p-16 max-w-3xl shadow-2xl rounded-sm">
              <Building2 size={48} className="text-brand-terra mx-auto mb-6" />
              <h3 className="font-serif text-3xl md:text-4xl text-brand-green mb-4">
                <Translate>For the Good of the City</Translate>
              </h3>
              <p className="text-brand-oak/90 text-lg">
                <Translate>We believe that when we create spaces for connection, the entire city begins to flourish. Healthy relationships are the bedrock of a healthy society.</Translate>
              </p>
           </div>
        </div>
      </section>

      {/* Section 2: The Goal */}
      <section className="max-w-7xl mx-auto px-6 py-12 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
           <div>
            <div className="flex items-center gap-3 mb-4">
              <Sprout size={28} className="text-brand-terra" />
              <span className="font-bold text-brand-green uppercase tracking-wider">
                <Translate>The Seed Fund</Translate>
              </span>
            </div>
            <h2 className="font-serif text-4xl text-brand-green mb-6">
              <Translate>Partner With Us</Translate>
            </h2>
            <div className="prose prose-lg text-brand-oak/80 leading-relaxed">
              <p className="mb-8">
                <Translate>We hope to raise the first $150,000 to establish the initial Third Space pilot and community presence.</Translate>
              </p>
              <p className="mb-6 border-l-4 border-brand-sand pl-6 italic font-serif">
                <Translate>Would you prayerfully consider being one of the founding supporters of this initiative? Your early partnership will help anchor a vision that has the potential to bless our city for years to come.</Translate>
              </p>
            </div>
            <div className="mt-8 flex flex-wrap gap-4">
               <Button to="/visit#support" className="rounded-full px-12 py-4">
                 <Translate>Support the Vision</Translate>
               </Button>
               <Button variant="outline" to="/visit" className="rounded-full px-12 py-4 border-brand-green text-brand-green">
                 <Translate>Contact the Founders</Translate>
               </Button>
            </div>
          </div>

          <div className="relative">
             <div className="grid grid-cols-2 gap-4">
                <img src="https://images.unsplash.com/photo-1534665482403-a909d0d97c67?q=80&w=2070&auto=format&fit=crop" className="rounded-sm shadow-md mt-12" alt="Watering a small plant" />
                <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop" className="rounded-sm shadow-md" alt="Team meeting" />
             </div>
          </div>
        </div>
      </section>

      {/* Final Visual: Beginnings */}
      <section className="bg-brand-sand/30 py-24 text-center mt-auto">
        <div className="max-w-4xl mx-auto px-6">
           <h2 className="font-serif text-4xl text-brand-green mb-8">
             <Translate>Join the Story</Translate>
           </h2>
           <p className="text-xl text-brand-oak/80 mb-10 leading-relaxed">
             <Translate>Every great community begins with a few people who decide to care. We invite you to be part of that beginning.</Translate>
           </p>
           <div className="flex justify-center">
             <Button to="/visit#support" className="text-lg px-12 py-5 flex items-center gap-3">
               <Translate>Become a Supporter</Translate> <ArrowRight size={20} />
             </Button>
           </div>
        </div>
      </section>
    </div>
  );
};
