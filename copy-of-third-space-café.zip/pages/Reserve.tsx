import React from 'react';
import { Button } from '../components/Button';
import { Calendar, Users, Clock, CheckCircle } from 'lucide-react';

export const Reserve: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-brand-cream">
      <div className="bg-brand-oak text-brand-cream py-16 px-6 text-center">
        <h1 className="font-serif text-5xl mb-4">Book a Table</h1>
        <p className="text-lg opacity-80 max-w-2xl mx-auto">Whether for a meeting, a date, or quiet study, reserve your spot in our shared space.</p>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          
          {/* Info Side */}
          <div>
            <h2 className="font-serif text-3xl text-brand-green mb-6">Reservation Policy</h2>
            <div className="space-y-6 text-brand-oak/80">
              <p>
                We keep 50% of our tables open for walk-ins to maintain our spirit of spontaneous hospitality. However, we understand the need for certainty sometimes.
              </p>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <CheckCircle size={20} className="text-brand-terra shrink-0 mt-1" />
                  <span>Reservations available for groups of 2-8 people.</span>
                </li>
                <li className="flex gap-3">
                  <CheckCircle size={20} className="text-brand-terra shrink-0 mt-1" />
                  <span>90-minute seating limit during peak hours (8am-11am).</span>
                </li>
                 <li className="flex gap-3">
                  <CheckCircle size={20} className="text-brand-terra shrink-0 mt-1" />
                  <span>For larger private events, please contact us directly.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-white p-8 rounded-sm shadow-lg border-t-4 border-brand-green">
            <h3 className="font-bold text-xl text-brand-green mb-6 flex items-center gap-2">
              <Calendar size={20}/> Make a Reservation
            </h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
               <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-brand-oak mb-2">Date</label>
                    <input type="date" className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra" />
                  </div>
                   <div>
                    <label className="block text-sm font-bold text-brand-oak mb-2">Time</label>
                    <select className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra">
                      <option>8:00 AM</option>
                      <option>9:00 AM</option>
                      <option>10:00 AM</option>
                      <option>11:00 AM</option>
                      <option>12:00 PM</option>
                      <option>1:00 PM</option>
                      <option>2:00 PM</option>
                    </select>
                  </div>
               </div>
               
               <div>
                  <label className="block text-sm font-bold text-brand-oak mb-2">Party Size</label>
                  <div className="relative">
                    <Users size={18} className="absolute left-3 top-3.5 text-brand-oak/40" />
                    <select className="w-full bg-brand-cream border border-brand-sand p-3 pl-10 rounded-sm focus:outline-none focus:border-brand-terra">
                      <option>2 People</option>
                      <option>3 People</option>
                      <option>4 People</option>
                      <option>5 People</option>
                      <option>6+ People</option>
                    </select>
                  </div>
               </div>

               <div>
                  <label className="block text-sm font-bold text-brand-oak mb-2">Your Name</label>
                  <input type="text" placeholder="Full Name" className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra" />
               </div>

               <div>
                  <label className="block text-sm font-bold text-brand-oak mb-2">Email</label>
                  <input type="email" placeholder="email@address.com" className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra" />
               </div>

               <Button className="w-full rounded-full">Confirm Reservation</Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};