import React from 'react';
import { Button } from '../components/Button';
import { Users, Armchair, ArrowRight, MapPin, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Translate } from '../components/Translate';

export const Home: React.FC = () => {
  const allPages = [
    { name: 'Home', path: '/' },
    { name: 'Our Story', path: '/story' },
    { name: 'The Café', path: '/coffee' },
    { name: 'Events', path: '/community' },
    { name: 'Contact', path: '/visit' },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center overflow-hidden pb-0">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1525610553991-2bede1a233e9?q=80&w=2070&auto=format&fit=crop" 
            alt="Warm inviting Third Space Café interior" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-brand-cream/70 backdrop-blur-[2px]"></div>
        </div>

        {/* Page Names Navigation at the Top of Home Page - Refined Spacing */}
        <div className="relative z-20 w-full pt-40 pb-6">
          <div className="max-w-7xl mx-auto px-6">
            <nav className="flex flex-wrap justify-center items-center gap-x-4 gap-y-3 md:gap-x-12">
              {allPages.map((page, index) => (
                <React.Fragment key={page.path}>
                  <Link
                    to={page.path}
                    className="text-[11px] md:text-sm font-bold uppercase tracking-[0.25em] text-brand-green/70 hover:text-brand-terra transition-all duration-300 hover:scale-105"
                  >
                    <Translate>{page.name}</Translate>
                  </Link>
                  {index < allPages.length - 1 && (
                    <span className="hidden md:block w-1 h-1 rounded-full bg-brand-terra/30"></span>
                  )}
                </React.Fragment>
              ))}
            </nav>
            <div className="w-full h-px bg-brand-green/10 mt-6 max-w-4xl mx-auto shadow-sm"></div>
          </div>
        </div>

        <div className="relative z-10 text-center text-brand-green max-w-5xl px-6 pt-10 flex flex-col items-center flex-grow justify-center">
          {/* Chalkboard Banner Image */}
          <div className="w-full max-w-lg h-32 md:h-44 rounded-2xl overflow-hidden shadow-2xl mb-12 border-4 border-brand-oak/20 transition-all hover:scale-[1.02] duration-500">
            <img 
              src="https://images.unsplash.com/photo-1514066558159-fc8c737ef259?q=80&w=2070&auto=format&fit=crop" 
              alt="Snacks and drinks drawn on a chalkboard" 
              className="w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-brand-green/10 mix-blend-overlay"></div>
          </div>
          
          <span className="block text-lg md:text-2xl font-bold uppercase tracking-[0.25em] mb-6 text-brand-terra">
            <Translate>Welcome to a place of belonging</Translate>
          </span>
          <h2 className="font-serif text-5xl md:text-6xl lg:text-7xl mb-10 leading-none">
            <Translate>A Space Without Edges</Translate>
          </h2>
          <p className="text-xl md:text-3xl font-medium mb-12 max-w-4xl mx-auto text-brand-oak/90 leading-relaxed">
            <Translate>Not home, Not workplace, not school - but a place to experience radical hospitality, delicious food, and flavor beverages.</Translate>
          </p>
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <Button to="/story" variant="outline" className="text-xl px-12 py-4 border-brand-green text-brand-green hover:bg-brand-green hover:text-white">
              <Translate>Our Story</Translate>
            </Button>
          </div>
        </div>
      </section>

      {/* The Triad - Set exactly 1.5 inches space above icons */}
      <section className="pt-[1.5in] pb-24 bg-brand-cream border-t border-brand-sand/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-12 text-center">
            <div className="flex flex-col items-center group">
              <div className="w-24 h-24 bg-brand-sand/50 rounded-full flex items-center justify-center text-brand-terra mb-8 overflow-hidden transition-transform group-hover:scale-110">
                <img 
                  src="https://lh3.googleusercontent.com/d/1uSj4_fwx3N9USYy7pe4oyybpRGTvwx-H" 
                  alt="The Café" 
                  className="w-14 h-14 object-contain"
                />
              </div>
              <h3 className="font-serif text-3xl mb-4 text-brand-green">
                <Translate>The Café</Translate>
              </h3>
              <p className="text-brand-oak/80 text-lg leading-relaxed px-4">
                <Translate>Sourced with intention, roasted with precision, and served with care. Craft lives in every cup.</Translate>
              </p>
            </div>
            <div className="flex flex-col items-center group">
              <div className="w-24 h-24 bg-brand-sand/50 rounded-full flex items-center justify-center text-brand-terra mb-8 transition-transform group-hover:scale-110">
                <Users size={44} />
              </div>
              <h3 className="font-serif text-3xl mb-4 text-brand-green">
                <Translate>The Community</Translate>
              </h3>
              <p className="text-brand-oak/80 text-lg leading-relaxed px-4">
                <Translate>A space designed for connection. Founded in dignity, open to everyone, always.</Translate>
              </p>
            </div>
            <div className="flex flex-col items-center group">
              <div className="w-24 h-24 bg-brand-sand/50 rounded-full flex items-center justify-center text-brand-terra mb-8 transition-transform group-hover:scale-110">
                <Armchair size={44} />
              </div>
              <h3 className="font-serif text-3xl mb-4 text-brand-green">
                <Translate>The Warmth Between Us</Translate>
              </h3>
              <p className="text-brand-oak/80 text-lg leading-relaxed px-4">
                <Translate>The tender warmth of being seen and welcomed. Happiness blooming in the space we share.</Translate>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="relative py-32 md:py-48 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1559925393-8be0ec4767c8?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
            alt="Bright Cafe Atmosphere" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-brand-cream/20"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-6 flex flex-col items-center text-center">
          <div className="bg-brand-cream/95 backdrop-blur-md px-10 py-16 md:p-16 shadow-2xl border border-brand-sand/30 rounded-tl-[60px] rounded-br-[60px] rounded-tr-[20px] rounded-bl-[20px] max-w-2xl w-full mx-auto">
            <h2 className="font-serif text-3xl md:text-5xl text-brand-green mb-6 leading-tight">
              <Translate>Brewed for Comfort, Crafted for Conversation</Translate>
            </h2>
            <Link to="/community" className="text-brand-terra hover:text-brand-oak text-base font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors">
              <Translate>Our Philosophy</Translate> <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Crafted with Care */}
      <section className="py-24 bg-brand-cream">
         <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="font-serif text-4xl text-brand-green mb-12">
                <Translate>Crafted with Care</Translate>
              </h2>
              
              <div className="flex flex-col md:flex-row gap-6 justify-center items-center mb-24">
                <Button to="/coffee" className="px-14 py-4 min-w-[220px] text-xl">
                  <Translate>View Menu</Translate>
                </Button>
                <Button to="/visit#support" variant="outline" className="px-14 py-4 min-w-[220px] text-xl border-brand-green text-brand-green hover:bg-brand-green hover:text-white">
                  <Translate>Support Us</Translate>
                </Button>
                <Button to="/reserve" variant="primary" className="px-14 py-4 min-w-[220px] text-xl bg-brand-green text-white hover:bg-brand-oak border-2 border-transparent">
                  <Translate>Book a Table</Translate>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start pt-16 border-t border-brand-sand">
               <div className="space-y-12">
                  <div>
                    <h3 className="font-serif text-3xl text-brand-green mb-6 flex items-center gap-3">
                      <MapPin className="text-brand-terra" /> <Translate>Find Us</Translate>
                    </h3>
                    <p className="text-xl text-brand-oak/80 leading-relaxed mb-4">
                      123 Community Ave,<br />
                      Neighbourhood, ST 90210
                    </p>
                  </div>

                  <div>
                    <h3 className="font-serif text-3xl text-brand-green mb-6 flex items-center gap-3">
                      <Clock className="text-brand-terra" /> <Translate>Hours</Translate>
                    </h3>
                    <div className="grid grid-cols-2 gap-x-12 gap-y-3 text-lg text-brand-oak/80">
                      <span className="font-bold text-brand-green"><Translate>Mon - Fri</Translate></span>
                      <span>7:00 AM – 8:00 PM</span>
                      <span className="font-bold text-brand-green"><Translate>Saturday</Translate></span>
                      <span>8:00 AM – 9:00 PM</span>
                      <span className="font-bold text-brand-green"><Translate>Sunday</Translate></span>
                      <span>8:00 AM – 6:00 PM</span>
                    </div>
                  </div>
               </div>

               <div className="w-full h-[400px] rounded-sm overflow-hidden shadow-lg border border-brand-sand relative group">
                  <iframe 
                    title="Third Space Café Location"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.123456789!2d-122.4194!3d37.7749!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085809c6c8f4433%3A0x7095a4369e63e2e!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1625000000000!5m2!1sen!2sus" 
                    className="w-full h-full grayscale contrast-125 opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700"
                    loading="lazy"
                  ></iframe>
               </div>
            </div>
         </div>
      </section>
    </div>
  );
};