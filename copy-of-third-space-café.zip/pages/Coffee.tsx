import React from 'react';

const MenuSection: React.FC<{ title: string; items: { name: string; desc: string; price: string }[] }> = ({ title, items }) => (
  <div className="mb-12">
    <h3 className="font-serif text-2xl text-brand-green border-b-2 border-brand-terra inline-block mb-6 pb-1">{title}</h3>
    <div className="space-y-6">
      {items.map((item, idx) => (
        <div key={idx} className="group">
          <div className="flex justify-between items-baseline mb-1">
            <h4 className="font-bold text-brand-oak text-lg group-hover:text-brand-terra transition-colors">{item.name}</h4>
            <span className="font-serif text-lg text-brand-green">{item.price}</span>
          </div>
          <p className="text-brand-oak/60 text-sm italic">{item.desc}</p>
        </div>
      ))}
    </div>
  </div>
);

export const Coffee: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-brand-cream">
      {/* Header */}
      <div className="bg-brand-green text-brand-cream py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="font-serif text-5xl md:text-6xl mb-6">The Ritual</h1>
          <p className="text-xl max-w-2xl mx-auto font-light text-brand-cream/80">
            Coffee is more than caffeine. It's a craft, a science, and an invitation to slow down.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Left: Philosophy */}
        <div className="lg:pr-12">
          <h2 className="font-serif text-3xl text-brand-green mb-6">From Seed to Cup</h2>
          <p className="text-brand-oak mb-6 leading-relaxed">
            We partner with roasters who pay direct-trade prices to farmers, ensuring dignity throughout the entire supply chain. Our beans are roasted to highlight their inherent terroir—bright, fruity, chocolatey, or nutty—without being burnt.
          </p>
          <img 
            src="https://picsum.photos/id/63/800/600" 
            alt="Barista Pouring Latte Art" 
            className="w-full h-80 object-cover rounded-sm shadow-md mb-8"
          />
          <h2 className="font-serif text-3xl text-brand-green mb-6">The Pour</h2>
          <p className="text-brand-oak leading-relaxed">
            Our baristas are trained artisans. Whether it's the precise weight of a V60 pour-over or the micro-foam texture of a flat white, we sweat the details so you can enjoy the moment.
          </p>
        </div>

        {/* Right: Menu */}
        <div className="bg-white p-8 md:p-12 shadow-sm rounded-sm border border-brand-sand/50">
          <MenuSection 
            title="Espresso"
            items={[
              { name: "Double Espresso", desc: "Syrupy, rich, and complex", price: "$3.50" },
              { name: "Macchiato", desc: "Espresso marked with a dollop of foam", price: "$4.00" },
              { name: "Cortado", desc: "1:1 ratio, smooth and balanced", price: "$4.50" },
              { name: "Cappuccino", desc: "Traditional 6oz, thick foam", price: "$4.75" },
              { name: "Latte", desc: "Creamy and comforting", price: "$5.25" },
            ]}
          />
          <MenuSection 
            title="Filter"
            items={[
              { name: "Batch Brew", desc: "Rotating single-origin, ready to go", price: "$3.50" },
              { name: "Pour Over (V60)", desc: "Hand-poured for clarity and nuance", price: "$5.50" },
              { name: "Chemex (For Two)", desc: "Clean, floral, shareable", price: "$9.00" },
            ]}
          />
          <MenuSection 
            title="Not Coffee"
            items={[
              { name: "Loose Leaf Tea", desc: "Assorted organic blends", price: "$4.00" },
              { name: "Chai Latte", desc: "Spicy house concentrate, steamed milk", price: "$5.50" },
              { name: "Craft Hot Chocolate", desc: "70% Dark Chocolate shavings", price: "$5.00" },
            ]}
          />
        </div>
      </div>
    </div>
  );
};