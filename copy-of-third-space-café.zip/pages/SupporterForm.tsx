
import React, { useState } from 'react';
import { Button } from '../components/Button';
import { Heart, Send, CheckCircle2, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export const SupporterForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    window.scrollTo(0, 0);
  };

  if (submitted) {
    return (
      <div className="pt-32 pb-24 min-h-screen bg-brand-cream flex items-center justify-center px-6 text-center">
        <div className="max-w-xl animate-in fade-in zoom-in duration-700">
          <div className="w-20 h-20 bg-brand-terra/10 text-brand-terra rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={40} />
          </div>
          <h1 className="font-serif text-4xl text-brand-green mb-4">Thank You for Believing</h1>
          <p className="text-xl text-brand-oak/80 mb-10 leading-relaxed">
            Your interest in being a Founding Supporter means the world to us. A member of our founding team will reach out to you personally within 48 hours to discuss how we can build this vision together.
          </p>
          <Button to="/supporters" variant="outline" className="rounded-full">
            Back to Vision
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-brand-cream">
      {/* Header */}
      <div className="bg-brand-green text-brand-cream py-16 md:py-24 px-6 text-center">
        <div className="max-w-3xl mx-auto">
          <Link to="/supporters" className="inline-flex items-center gap-2 text-brand-terra font-bold uppercase tracking-widest text-xs mb-8 hover:text-white transition-colors">
            <ArrowLeft size={14} /> Back to Founders Page
          </Link>
          <h1 className="font-serif text-4xl md:text-6xl mb-6">Support the Vision</h1>
          <p className="text-xl text-brand-cream/80 font-light">
            Tell us a little about yourself and how you'd like to help anchor a new "third space" in our city.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-white p-8 md:p-12 rounded-sm shadow-xl border border-brand-sand/50 grid grid-cols-1 md:grid-cols-5 gap-12">
          
          {/* Form Side */}
          <div className="md:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">Full Name</label>
                  <input 
                    required 
                    type="text" 
                    className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                    placeholder="Enter your name" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">Email Address</label>
                  <input 
                    required 
                    type="email" 
                    className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                    placeholder="you@example.com" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">Phone Number</label>
                  <input 
                    type="tel" 
                    className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                    placeholder="(555) 000-0000" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">Area of Interest</label>
                  <select className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors appearance-none cursor-pointer">
                    <option>Founding Financial Supporter</option>
                    <option>Vision & Strategy Partner</option>
                    <option>Volunteer Leadership</option>
                    <option>Community Advocate</option>
                    <option>Just want to stay updated</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">Message or Vision</label>
                  <textarea 
                    rows={4} 
                    className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                    placeholder="What excites you most about Third Space?"
                  ></textarea>
                </div>
              </div>

              <Button className="w-full py-5 text-lg flex items-center gap-3 group">
                Submit Interest <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </Button>
            </form>
          </div>

          {/* Context Side */}
          <div className="md:col-span-2 space-y-8">
            <div className="p-6 bg-brand-sand/30 rounded-sm border-l-4 border-brand-terra">
              <Heart className="text-brand-terra mb-4" />
              <h3 className="font-serif text-xl text-brand-green mb-3">A Collaborative Beginning</h3>
              <p className="text-sm text-brand-oak/80 leading-relaxed">
                We aren't just looking for funding; we are looking for partners. Your insight, network, and belief in this vision are just as valuable as financial contributions.
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-brand-terra">What happens next?</h4>
              <ul className="text-sm text-brand-oak/70 space-y-4">
                <li className="flex gap-3">
                  <span className="w-6 h-6 rounded-full bg-brand-green text-white flex items-center justify-center text-[10px] shrink-0">1</span>
                  <span>We'll review your interest and reach out for a casual coffee (on us).</span>
                </li>
                <li className="flex gap-3">
                  <span className="w-6 h-6 rounded-full bg-brand-green text-white flex items-center justify-center text-[10px] shrink-0">2</span>
                  <span>We'll share the full 3-year vision and pilot project roadmap.</span>
                </li>
                <li className="flex gap-3">
                  <span className="w-6 h-6 rounded-full bg-brand-green text-white flex items-center justify-center text-[10px] shrink-0">3</span>
                  <span>We'll discuss the most meaningful way for you to be involved.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
