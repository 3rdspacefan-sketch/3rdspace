import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Calendar } from 'lucide-react';

interface EventData {
  title: string;
  recurrence: string;
  image: string;
  description: string;
  time?: string;
}

const eventsList: EventData[] = [
  {
    title: "Weekly Café Club",
    recurrence: "Weekly",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1974&auto=format&fit=crop",
    description: "Join us every Tuesday morning to explore different single-origin roasts. It is a casual time to taste, learn about coffee origins from our head barista, and meet other coffee enthusiasts in the neighborhood. No prior knowledge required—just a love for a good cup.",
    time: "Tuesdays @ 8:00 AM"
  },
  {
    title: "Newcomer Welcome Table",
    recurrence: "Weekly",
    image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=2070&auto=format&fit=crop",
    description: "New to the city or just looking for a fresh start? We reserve a specific community table every week just for you. Hosted by a friendly regular, it is the perfect low-pressure way to make your first friend here. Look for the 'Welcome' sign on the long oak table.",
    time: "Wednesdays @ 6:00 PM"
  },
  {
    title: "Life & Meaning Conversations",
    recurrence: "Biweekly",
    image: "https://images.unsplash.com/photo-1573166364524-d9dbfd8bbf83?q=80&w=2069&auto=format&fit=crop",
    description: "A facilitated space to discuss the questions that matter. We explore topics of purpose, ethics, anxiety, and spirituality in a respectful, open environment where listening is prioritized over debating. All backgrounds and beliefs are welcome at the table.",
    time: "Every other Thursday @ 7:00 PM"
  },
  {
    title: "Open Mic Night",
    recurrence: "Monthly",
    image: "https://images.unsplash.com/photo-1598387993441-a364f854c3e1?q=80&w=2076&auto=format&fit=crop",
    description: "Our stage is yours. Whether you write poetry, play acoustic folk, stand-up comedy, or have a story to tell, come share your gift. It is a safe, encouraging atmosphere for first-timers and seasoned pros alike. Sign-ups start 30 minutes before the show.",
    time: "Last Friday of the Month @ 7:30 PM"
  },
  {
    title: "Meet Your Neighbour",
    recurrence: "Monthly",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=2069&auto=format&fit=crop",
    description: "A classic potluck-style dinner designed to shrink the distance between addresses. We provide the main dish and drinks; you bring a side or dessert if you can (or just bring yourself—there is always enough). Come as a stranger, leave as a neighbor.",
    time: "First Sunday of the Month @ 5:00 PM"
  },
  {
    title: "Low-cost Art & Craft Workshop",
    recurrence: "Monthly",
    image: "https://images.unsplash.com/photo-1452860606245-08befc0ff44b?q=80&w=2080&auto=format&fit=crop",
    description: "Unleash your inner artist without the high price tag. We provide materials for a different project each month—from watercolor painting to pottery basics. It is a pay-what-you-can event designed to make creativity accessible to everyone regardless of budget.",
    time: "Second Saturday of the Month @ 2:00 PM"
  }
];

const EventCard: React.FC<{ event: EventData }> = ({ event }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white rounded-sm shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col h-full border border-brand-sand/20 group">
      {/* Image Container */}
      <div className="h-56 overflow-hidden relative">
        <img 
          src={event.image} 
          alt={event.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
        />
        <div className="absolute top-4 left-4 bg-brand-cream/95 backdrop-blur-sm px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-brand-terra rounded-sm shadow-sm border-l-2 border-brand-terra">
          {event.recurrence}
        </div>
      </div>

      {/* Content */}
      <div className="p-6 md:p-8 flex flex-col flex-grow">
        <h3 className="font-serif text-2xl text-brand-green mb-3">{event.title}</h3>
        
        {event.time && (
          <div className="flex items-center gap-2 text-sm font-bold text-brand-oak/60 mb-4 uppercase tracking-wider">
            <Calendar size={14} className="text-brand-terra" />
            {event.time}
          </div>
        )}

        {/* Spacer to push button to bottom if needed, or just visual space */}
        <div className="flex-grow"></div>

        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-between text-sm font-bold text-brand-green hover:text-brand-terra transition-colors pt-4 border-t border-brand-sand/30 mt-2"
          aria-expanded={isExpanded}
        >
          <span>{isExpanded ? "Close Details" : "Click to expand"}</span>
          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </button>

        {/* Collapsible Section */}
        <div 
          className={`grid transition-[grid-template-rows] duration-500 ease-in-out ${isExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
        >
          <div className="overflow-hidden">
            <p className="pt-4 text-brand-oak/80 leading-relaxed text-base">
              {event.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export const Community: React.FC = () => {
  return (
    <div className="pt-24 min-h-screen bg-brand-cream flex flex-col">
      {/* Header */}
      <div className="bg-brand-green text-brand-cream py-16 md:py-24 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <span className="text-brand-terra font-bold tracking-widest uppercase text-sm mb-4 block">Connect with Us</span>
          <h1 className="font-serif text-5xl md:text-6xl mb-6">Recurring Events</h1>
          <p className="text-xl max-w-2xl mx-auto font-light text-brand-cream/80">
            Consistency builds community. These regular gatherings are the heartbeat of our space—open to everyone, always.
          </p>
        </div>
      </div>

      {/* Events Grid */}
      <div className="max-w-7xl mx-auto px-6 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10">
          {eventsList.map((event, idx) => (
            <EventCard key={idx} event={event} />
          ))}
        </div>
      </div>

      {/* Footer Call to Action */}
      <div className="bg-brand-sand/30 py-16 text-center">
         <div className="max-w-2xl mx-auto px-6">
            <h2 className="font-serif text-3xl text-brand-green mb-4">Have an idea for a gathering?</h2>
            <p className="text-brand-oak/80 mb-8">
              We love supporting community-led initiatives. If you want to host a book club, knitting circle, or discussion group, let's talk.
            </p>
            <a href="/visit" className="inline-block text-brand-terra font-bold border-b-2 border-brand-terra hover:text-brand-oak hover:border-brand-oak transition-colors">
              Contact our Community Manager
            </a>
         </div>
      </div>
    </div>
  );
};