import React, { useState } from 'react';
import { Button } from '../components/Button';
import { MapPin, Clock, Phone, Mail, Heart, Send, CheckCircle2 } from 'lucide-react';
import { Translate } from '../components/Translate';

export const Visit: React.FC = () => {
  const [supporterSubmitted, setSupporterSubmitted] = useState(false);
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const handleSupporterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending to 3tdspacefan@gmail.com
    console.log("Form data sent to 3tdspacefan@gmail.com");
    setSupporterSubmitted(true);
    const element = document.getElementById('support');
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending to 3tdspacefan@gmail.com
    console.log("Contact message sent to 3tdspacefan@gmail.com");
    setContactSubmitted(true);
  };

  return (
    <div className="pt-24 min-h-screen bg-brand-cream flex flex-col">
      {/* Contact Section */}
      <div className="flex-grow max-w-7xl mx-auto px-6 py-16 w-full grid grid-cols-1 lg:grid-cols-2 gap-16 border-b border-brand-sand/30">
        
        {/* Info Column */}
        <div className="pt-8">
          <h1 className="font-serif text-5xl text-brand-green mb-8">
            <Translate>Contact</Translate>
          </h1>
          <p className="text-xl text-brand-oak/80 mb-12 leading-relaxed">
            <Translate>We are located in the heart of the district, right next to the old library. Come say hello.</Translate>
          </p>

          <div className="space-y-10">
            <div className="flex gap-5">
              <div className="w-12 h-12 rounded-full bg-brand-sand/50 flex items-center justify-center shrink-0">
                <MapPin className="text-brand-terra" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-brand-green text-lg"><Translate>Location</Translate></h3>
                <p className="text-brand-oak/80 text-lg">123 Community Ave,<br/>Neighbourhood, ST 90210</p>
              </div>
            </div>

            <div className="flex gap-5">
              <div className="w-12 h-12 rounded-full bg-brand-sand/50 flex items-center justify-center shrink-0">
                <Clock className="text-brand-terra" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-brand-green text-lg"><Translate>Hours</Translate></h3>
                <div className="grid grid-cols-2 gap-x-12 text-brand-oak/80 text-lg">
                  <span className="font-medium"><Translate>Mon - Fri</Translate></span>
                  <span>7:00 AM - 8:00 PM</span>
                  <span className="font-medium"><Translate>Saturday</Translate></span>
                  <span>8:00 AM - 9:00 PM</span>
                  <span className="font-medium"><Translate>Sunday</Translate></span>
                  <span>8:00 AM - 6:00 PM</span>
                </div>
              </div>
            </div>

            <div className="flex gap-5">
              <div className="w-12 h-12 rounded-full bg-brand-sand/50 flex items-center justify-center shrink-0">
                <Mail className="text-brand-terra" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-brand-green text-lg"><Translate>Contact</Translate></h3>
                <p className="text-brand-oak/80 text-lg">hello@thirdspacecafe.com</p>
                <p className="text-brand-oak/80 text-lg">(555) 123-4567</p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Column */}
        <div className="bg-white p-10 md:p-12 rounded-sm shadow-xl border border-brand-sand/50 flex flex-col justify-center">
          {contactSubmitted ? (
            <div className="text-center py-12 animate-in fade-in zoom-in duration-500">
              <div className="w-16 h-16 bg-brand-green/10 text-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 size={32} />
              </div>
              <h2 className="font-serif text-3xl text-brand-green mb-4"><Translate>Message Sent</Translate></h2>
              <p className="text-brand-oak/80 mb-8">
                <Translate>Thank you for reaching out. Your message has been sent to</Translate> <strong>3tdspacefan@gmail.com</strong>. <Translate>We will get back to you shortly.</Translate>
              </p>
              <Button onClick={() => setContactSubmitted(false)} variant="outline" className="h-12 w-2/3 mx-auto text-xl">
                <Translate>Send Another</Translate>
              </Button>
            </div>
          ) : (
            <>
              <h2 className="font-serif text-3xl text-brand-green mb-8">
                <Translate>Send us a note</Translate>
              </h2>
              <form className="space-y-6 flex flex-col" onSubmit={handleContactSubmit}>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">
                    <Translate>Name</Translate>
                  </label>
                  <input required type="text" className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" placeholder="Jane Doe" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">
                    <Translate>Email</Translate>
                  </label>
                  <input required type="email" className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" placeholder="jane@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-2">
                    <Translate>Message</Translate>
                  </label>
                  <textarea required rows={4} className="w-full bg-brand-cream border border-brand-sand p-3 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" placeholder="How can we help?"></textarea>
                </div>
                <Button type="submit" className="w-2/3 mx-auto h-12 text-xl shadow-sm">
                  <Translate>Send Message</Translate>
                </Button>
              </form>
            </>
          )}
        </div>
      </div>

      {/* Support the Vision Section */}
      <section id="support" className="py-24 bg-brand-cream scroll-mt-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="max-w-2xl mx-auto mb-10 rounded-sm overflow-hidden shadow-md border border-brand-sand/30">
              <img 
                src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=2070&auto=format&fit=crop" 
                alt="Support the Vision" 
                className="w-full h-auto object-cover"
              />
            </div>
            <h2 className="font-serif text-5xl md:text-6xl text-brand-green mb-6">
              <Translate>Support the Vision</Translate>
            </h2>
            <p className="text-xl text-brand-oak/70 max-w-3xl mx-auto leading-relaxed">
              <Translate>Tell us a little about yourself and how you'd like to help anchor a new "third space" in our city.</Translate>
            </p>
          </div>

          {supporterSubmitted ? (
            <div className="max-w-3xl mx-auto text-center py-20 bg-white rounded-sm shadow-xl border border-brand-sand/50 animate-in fade-in zoom-in duration-700">
              <div className="w-24 h-24 bg-brand-terra/10 text-brand-terra rounded-full flex items-center justify-center mx-auto mb-10">
                <CheckCircle2 size={48} />
              </div>
              <h3 className="font-serif text-4xl text-brand-green mb-6"><Translate>Thank You for Believing</Translate></h3>
              <p className="text-2xl text-brand-oak/80 mb-6 px-10 leading-relaxed font-serif italic">
                <Translate>"Your interest in being a Founding Supporter means the world to us."</Translate>
              </p>
              <p className="text-brand-oak/70 mb-12 px-10">
                <Translate>Your application has been received at</Translate> <strong>3tdspacefan@gmail.com</strong>. <Translate>A member of our founding team will reach out to you personally within 48 hours.</Translate>
              </p>
              <Button onClick={() => setSupporterSubmitted(false)} variant="outline" className="h-12 w-2/3 mx-auto text-xl">
                <Translate>Back to Support Form</Translate>
              </Button>
            </div>
          ) : (
            <div className="bg-white p-8 md:p-16 rounded-sm shadow-2xl border border-brand-sand/50 grid grid-cols-1 lg:grid-cols-5 gap-16">
              {/* Form Side */}
              <div className="lg:col-span-3">
                <form onSubmit={handleSupporterSubmit} className="space-y-8 flex flex-col">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-3"><Translate>Full Name</Translate></label>
                      <input 
                        required 
                        type="text" 
                        className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                        placeholder="Enter your name" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-3"><Translate>Email Address</Translate></label>
                      <input 
                        required 
                        type="email" 
                        className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                        placeholder="you@example.com" 
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-3"><Translate>Phone Number</Translate></label>
                      <input 
                        type="tel" 
                        className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                        placeholder="(555) 000-0000" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-3"><Translate>Area of Interest</Translate></label>
                      <select className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors appearance-none cursor-pointer">
                        <option>Founding Financial Supporter</option>
                        <option>Vision & Strategy Partner</option>
                        <option>Volunteer Leadership</option>
                        <option>Community Advocate</option>
                        <option>Just want to stay updated</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-brand-green uppercase tracking-wider mb-3"><Translate>Message or Vision</Translate></label>
                    <textarea 
                      rows={5} 
                      className="w-full bg-brand-cream border border-brand-sand p-4 rounded-sm focus:outline-none focus:border-brand-terra transition-colors" 
                      placeholder="What excites you most about Third Space?"
                    ></textarea>
                  </div>

                  <Button type="submit" className="w-2/3 mx-auto h-12 text-xl flex items-center justify-center gap-4 group">
                    <Translate>Submit Interest</Translate> <Send size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </Button>
                </form>
              </div>

              {/* Context Side */}
              <div className="lg:col-span-2 space-y-12">
                <div className="p-10 bg-brand-sand/30 rounded-sm border-l-8 border-brand-terra shadow-sm">
                  <Heart className="text-brand-terra mb-6" size={40} />
                  <h3 className="font-serif text-2xl text-brand-green mb-4"><Translate>A Collaborative Beginning</Translate></h3>
                  <p className="text-lg text-brand-oak/80 leading-relaxed">
                    <Translate>We aren't just looking for funding; we are looking for partners. Your insight, network, and belief in this vision are just as valuable as financial contributions.</Translate>
                  </p>
                </div>

                <div className="space-y-6">
                  <h4 className="text-sm font-bold uppercase tracking-[0.3em] text-brand-terra"><Translate>What happens next?</Translate></h4>
                  <ul className="text-lg text-brand-oak/70 space-y-6">
                    <li className="flex gap-4">
                      <span className="w-10 h-10 rounded-full bg-brand-green text-white flex items-center justify-center text-sm font-bold shrink-0">1</span>
                      <span><Translate>We'll review your interest and reach out for a casual coffee (on us).</Translate></span>
                    </li>
                    <li className="flex gap-4">
                      <span className="w-10 h-10 rounded-full bg-brand-green text-white flex items-center justify-center text-sm font-bold shrink-0">2</span>
                      <span><Translate>We'll share the full 3-year vision and pilot project roadmap.</Translate></span>
                    </li>
                    <li className="flex gap-4">
                      <span className="w-10 h-10 rounded-full bg-brand-green text-white flex items-center justify-center text-sm font-bold shrink-0">3</span>
                      <span><Translate>We'll discuss the most meaningful way for you to be involved.</Translate></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};