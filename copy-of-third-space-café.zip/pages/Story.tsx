import React, { useState, useEffect } from 'react';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

export const Story: React.FC = () => {
  const images = [
    "https://lh3.googleusercontent.com/d/1cPsgxr7BbgYoOka0ppRiLvKwXFKnvjC4",
    "https://lh3.googleusercontent.com/d/1jJI-Fs2yEM-C6T4sVmTj37rTPZUQxmq8",
    "https://lh3.googleusercontent.com/d/1fuIZC1QsOGmfsGDCCNqv-RvbODy6Y8Jm",
    "https://lh3.googleusercontent.com/d/1yFnOEYIg-n-KM753CyO7sFUFokNjHW0F"
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [images.length]);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  return (
    <div className="pt-24 bg-brand-cream min-h-screen">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <span className="text-brand-terra font-bold tracking-widest uppercase text-sm mb-3 block">Our Roots</span>
          <h1 className="font-serif text-5xl md:text-6xl text-brand-green mb-6">Why We Exist</h1>
          <div className="w-24 h-1 bg-brand-terra mx-auto rounded-full"></div>
        </div>

        <div className="prose prose-lg prose-stone mx-auto text-brand-oak">
          <p className="lead text-xl md:text-2xl font-serif text-brand-green italic mb-8">
            In today’s increasingly fragmented and isolated society, many people no longer feel a sense of belonging. We believe communities need a “third path” — a welcoming place between home and work, beyond institutional barriers, where genuine human connection can grow.
          </p>

          <p className="text-xl md:text-2xl font-serif text-brand-oak italic mb-8">
            The 3rd Space is designed to be that place: a hospitality-anchored community hub where young adults, families, and seniors can gather, build friendships, and rediscover meaning and hope. Your support will help create lasting social impact by restoring the relationships that make healthy communities possible.
          </p>

          {/* Automotive Slideshow */}
          <div className="my-12 relative group rounded-sm overflow-hidden shadow-xl bg-brand-sand/20 border border-brand-sand/30">
            <div className="relative w-full h-[300px] md:h-[500px]">
              {images.map((img, index) => (
                <img 
                  key={index}
                  src={img} 
                  alt={`Gallery Image ${index + 1}`} 
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}
                />
              ))}
              
              {/* Navigation Controls */}
              <button 
                onClick={prevSlide}
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-brand-cream/80 hover:bg-brand-white text-brand-green p-3 rounded-full shadow-md backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 transform group-hover:translate-x-0 -translate-x-4 z-10"
                aria-label="Previous slide"
              >
                <ChevronLeft size={24} />
              </button>
              
              <button 
                onClick={nextSlide}
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-brand-cream/80 hover:bg-brand-white text-brand-green p-3 rounded-full shadow-md backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 transform group-hover:translate-x-4 translate-x-4 z-10"
                aria-label="Next slide"
              >
                <ChevronRight size={24} />
              </button>

              {/* Dots Indicator */}
              <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-10">
                {images.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-2 rounded-full transition-all duration-300 shadow-sm ${idx === currentIndex ? 'bg-brand-terra w-8' : 'bg-white/60 hover:bg-white w-2'}`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>

          <h2 className="font-serif text-3xl text-brand-green mt-12 mb-4">Founded in Faith, Rooted in Love</h2>
          <p className="mb-6">
            Third Space was founded by a group of friends from a local Christian community who asked a simple question: <em>"What does our neighborhood actually need?"</em> The answer wasn't a church program or a sermon. It was a place where walls come down.
          </p>
          <p className="mb-6">
            While our motivation springs from the Christian tradition of radical hospitality—the ancient practice of welcoming the stranger as if they were divine—our table is open to absolutely everyone.
          </p>

          <div className="bg-brand-sand/30 p-8 rounded-sm border-l-4 border-brand-terra my-8">
             <h3 className="font-bold text-brand-green mb-2">What we mean by "Open to Everyone"</h3>
             <p className="italic text-brand-oak/80">
               We mean it literally. Whether you are spiritual, skepticism, wealthy, struggling, happy, or hurting—you belong here. We don't use coffee to preach; we use coffee to serve.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};