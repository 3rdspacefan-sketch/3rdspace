export interface MenuItem {
  name: string;
  description: string;
  price: string;
  category: 'coffee' | 'tea' | 'food';
}

export interface NavLink {
  label: string;
  path: string;
}

export interface Event {
  title: string;
  date: string;
  time: string;
  description: string;
}