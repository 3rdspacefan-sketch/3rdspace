import React, { useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Story } from './pages/Story';
import { Coffee } from './pages/Coffee';
import { Community } from './pages/Community';
import { Visit } from './pages/Visit';
import { Reserve } from './pages/Reserve';
import { FoundingSupporters } from './pages/FoundingSupporters';
import { LanguageProvider } from './context/LanguageContext';

const ScrollToTop = () => {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (!hash) {
      window.scrollTo(0, 0);
    } else {
      const id = hash.replace('#', '');
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [pathname, hash]);
  return null;
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <HashRouter>
        <ScrollToTop />
        <div className="flex flex-col min-h-screen font-sans text-brand-oak bg-brand-cream selection:bg-brand-terra selection:text-white">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/story" element={<Story />} />
              <Route path="/coffee" element={<Coffee />} />
              <Route path="/community" element={<Community />} />
              <Route path="/visit" element={<Visit />} />
              <Route path="/reserve" element={<Reserve />} />
              <Route path="/supporters" element={<FoundingSupporters />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </HashRouter>
    </LanguageProvider>
  );
};

export default App;