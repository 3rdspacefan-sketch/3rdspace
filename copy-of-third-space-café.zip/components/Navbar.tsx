import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { NavLink } from '../types';
import { useLanguage, Language } from '../context/LanguageContext';
import { Translate } from './Translate';

const links: NavLink[] = [
  { label: 'Our Story', path: '/story' },
  { label: 'The Café', path: '/coffee' },
  { label: 'Events', path: '/community' },
  { label: 'Contact', path: '/visit' },
  { label: 'Founding Supporters', path: '/supporters' },
];

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { language, setLanguage } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const logoTextClass = 'text-brand-green';
  const linkBaseClass = 'text-brand-green hover:text-brand-terra';
  const linkActiveClass = 'text-brand-terra';
  const mobileToggleClass = 'text-brand-green';

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 bg-brand-cream border-b border-brand-sand/30 ${scrolled ? 'py-3' : 'py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Logo and Language Switcher */}
        <div className="flex flex-col items-start gap-2">
          <Link to="/" className="flex items-center gap-4 group">
            <img 
              src="https://lh3.googleusercontent.com/d/1uSj4_fwx3N9USYy7pe4oyybpRGTvwx-H" 
              alt="Third Space Logo" 
              className="h-14 w-auto object-contain transition-transform group-hover:scale-105" 
            />
            <span className={`font-serif text-3xl font-bold tracking-tight transition-colors ${logoTextClass}`}>
              Third Space
            </span>
          </Link>
          
          {/* Language Switcher - Enlarged to 2xl */}
          <div className="flex gap-10 text-2xl font-bold uppercase tracking-[0.1em] text-brand-oak/60 ml-[72px] mt-2">
            {(['en', 'zh-hans', 'zh-hant'] as Language[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`hover:text-brand-terra transition-colors pb-1 border-b-4 ${language === lang ? 'text-brand-terra border-brand-terra' : 'border-transparent'}`}
              >
                {lang === 'en' ? 'EN' : lang === 'zh-hans' ? '简体' : '繁體'}
              </button>
            ))}
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-6 xl:gap-8">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-sm font-bold uppercase tracking-widest transition-colors ${
                location.pathname === link.path ? linkActiveClass : linkBaseClass
              }`}
            >
              <Translate>{link.label}</Translate>
            </Link>
          ))}
          <Link 
            to="/visit#support" 
            className="px-8 py-3 bg-brand-terra text-white text-sm font-bold uppercase tracking-wider hover:bg-brand-oak transition-colors rounded-full shadow-md"
          >
            <Translate>Support Us</Translate>
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button 
          className={`lg:hidden ${mobileToggleClass}`}
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden absolute top-full left-0 w-full bg-brand-cream border-t border-brand-sand transition-all duration-300 overflow-hidden shadow-xl ${isOpen ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="flex flex-col p-6 gap-4">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-brand-green font-serif text-xl hover:text-brand-terra"
            >
              <Translate>{link.label}</Translate>
            </Link>
          ))}
          <Link 
            to="/visit#support"
            className="mt-4 text-center py-3 bg-brand-terra text-white font-bold uppercase tracking-wider rounded-full"
          >
            <Translate>Support Us</Translate>
          </Link>
        </div>
      </div>
    </nav>
  );
};