
import React from 'react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: React.ReactNode;
  to?: string;
  variant?: 'primary' | 'outline' | 'text';
  className?: string;
  onClick?: () => void;
  // Added type prop to support standard HTML button behavior in forms
  type?: 'button' | 'submit' | 'reset';
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  to, 
  variant = 'primary', 
  className = '',
  onClick,
  // Passing through the type prop to the underlying button element
  type
}) => {
  const baseStyles = "inline-flex items-center justify-center px-8 py-3 text-sm font-bold tracking-wide transition-all duration-300 rounded-full";
  
  const variants = {
    primary: "bg-brand-terra text-white hover:bg-brand-oak hover:shadow-lg",
    outline: "border-2 border-brand-green text-brand-green hover:bg-brand-green hover:text-white",
    text: "text-brand-terra hover:text-brand-oak underline-offset-4 hover:underline"
  };

  const combinedClasses = `${baseStyles} ${variants[variant]} ${className}`;

  if (to) {
    return (
      <Link to={to} className={combinedClasses}>
        {children}
      </Link>
    );
  }

  // Pass type to the native button element
  return (
    <button type={type} onClick={onClick} className={combinedClasses}>
      {children}
    </button>
  );
};