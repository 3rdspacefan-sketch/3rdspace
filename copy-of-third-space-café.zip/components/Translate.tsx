
import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

interface TranslateProps {
  children: string;
}

export const Translate: React.FC<TranslateProps> = ({ children }) => {
  const { language, translate } = useLanguage();
  const [displayText, setDisplayText] = useState(children);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (language === 'en') {
      setDisplayText(children);
      setLoading(false);
      return;
    }

    const performTranslation = async () => {
      setLoading(true);
      const result = await translate(children);
      setDisplayText(result);
      setLoading(false);
    };

    performTranslation();
  }, [language, children, translate]);

  if (loading) {
    return (
      <span className="opacity-40 transition-opacity">
        {displayText}
      </span>
    );
  }

  return <>{displayText}</>;
};
